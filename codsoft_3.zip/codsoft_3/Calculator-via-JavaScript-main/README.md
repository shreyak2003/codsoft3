<h1 align="center">Calculator App Project ➕ ➖✖️➗</h1>

## Hello Developers and Hackers i'm Nazu from Ethiopia.
### Today I made A basic Calculator App Developed using #HTML , #CSS and #JavaScript.

### How to contribute :

    Make a Fork.
    Clone the repository to your local desktop.
    Select the folder(what you are creating)
    Create new folder inside the selected folder and give it a name (It's necessary).
    Make changes and Add to Staging here.
    Commit changes [always write the message short and easy to understand (ideally 3 to 5 words).]
    Push the changes so that Pull request will be generated.
    Make PR.
    Commits should be descriptive.


![105](https://user-images.githubusercontent.com/108541991/192867927-35e06920-9ada-4f04-a4a2-de71cdfdb168.jpg)

<h1 align="center">Result</h1>

![100](https://user-images.githubusercontent.com/108541991/192867952-f0f72775-7734-4938-be28-669208e1c87f.jpg)
